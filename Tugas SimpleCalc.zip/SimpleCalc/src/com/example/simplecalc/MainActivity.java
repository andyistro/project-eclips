package com.example.simplecalc;

import android.os.Bundle;
import android.app.Activity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

	EditText et1, et2;
	Button b1, b2, b3;
	TextView tv1;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		et1 = (EditText) findViewById(R.id.editText1);
		et2 = (EditText) findViewById(R.id.editText2);

		b1 = (Button) findViewById(R.id.button1);
		b2 = (Button) findViewById(R.id.button2);
		b3 = (Button) findViewById(R.id.button3);

		tv1 = (TextView) findViewById(R.id.textView1);

		b1.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {

				try {
					int angka1 = Integer.parseInt(et1.getText().toString());
					int angka2 = Integer.parseInt(et2.getText().toString());

					int hasil = angka1 + angka2;
					tv1.setText(String.valueOf(hasil));

				} catch (Exception e) {
					Toast.makeText(getBaseContext(), "Salah", Toast.LENGTH_LONG).show();
				}

			}
		});

		b2.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {

				try {
					int angka1 = Integer.parseInt(et1.getText().toString());
					int angka2 = Integer.parseInt(et2.getText().toString());

					int hasil = angka1 * angka2;
					tv1.setText(String.valueOf(hasil));

				} catch (Exception e) {
					Toast.makeText(getBaseContext(), "Salah", Toast.LENGTH_LONG).show();
				}

			}
		});

		b3.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {

				try {
					double angka1 = Double.parseDouble(et1.getText().toString());
					double angka2 = Double.parseDouble(et2.getText().toString());

					double hasil = angka1 / angka2;
					tv1.setText(String.valueOf(hasil));
					
				} catch (Exception e) {
					Toast.makeText(getBaseContext(), "Salah", Toast.LENGTH_LONG).show();
				}

			}
		});

	}

}
